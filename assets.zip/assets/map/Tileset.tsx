<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Tileset" tilewidth="32" tileheight="32" tilecount="60" columns="10">
 <image source="Tileset.png" width="320" height="192"/>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0722837" y="0.0722837" width="31.9494" height="31.8048"/>
   <object id="2" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
</tileset>
