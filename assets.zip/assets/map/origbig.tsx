<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="origbig" tilewidth="32" tileheight="32" tilecount="2880" columns="72">
 <image source="origbig.png" width="2304" height="1296"/>
</tileset>
