<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="TX Chest Animation" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="../Texture/TX Chest Animation.png" width="512" height="512"/>
</tileset>
