<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Weeping Willow1" tilewidth="32" tileheight="32" tilecount="42" columns="7">
 <image source="../GandalfHardcore FREE Platformer Assets/Weeping Willow1.png" width="224" height="192"/>
</tileset>
