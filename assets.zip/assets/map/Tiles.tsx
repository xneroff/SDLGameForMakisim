<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Tiles" tilewidth="32" tileheight="32" tilecount="18" columns="6">
 <image source="../Demo/Tiles.png" width="192" height="96"/>
</tileset>
