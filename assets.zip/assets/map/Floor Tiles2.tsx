<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Floor Tiles2" tilewidth="32" tileheight="32" tilecount="162" columns="9">
 <image source="../GandalfHardcore FREE Platformer Assets/Floor Tiles2.png" width="288" height="576"/>
</tileset>
