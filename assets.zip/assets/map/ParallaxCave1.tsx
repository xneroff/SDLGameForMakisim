<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="ParallaxCave1" tilewidth="32" tileheight="32" tilecount="1224" columns="36">
 <image source="../PNG files/ParallaxCave1.png" width="1152" height="1088"/>
</tileset>
