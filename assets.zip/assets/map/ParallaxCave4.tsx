<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="ParallaxCave4" tilewidth="32" tileheight="32" tilecount="720" columns="36">
 <image source="../PNG files/ParallaxCave4.png" width="1152" height="640"/>
</tileset>
