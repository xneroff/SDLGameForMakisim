<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="7" tilewidth="32" tileheight="32" tilecount="180" columns="18">
 <image source="../nature_1/7.png" width="576" height="324"/>
</tileset>
