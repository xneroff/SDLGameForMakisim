<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="TX Village Props" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="../Texture/TX Village Props.png" width="1024" height="1024"/>
</tileset>
